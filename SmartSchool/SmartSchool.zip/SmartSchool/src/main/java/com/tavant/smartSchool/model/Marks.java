package com.tavant.smartSchool.model;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Marks {
	
	
	String sub_name;
	int marks;
	@ManyToOne
	@JoinColumn(name="s_id")
	private Student student;
	 
	public String getSub_name() {
		return sub_name;
	}
	public void setSub_name(String sub_name) {
		this.sub_name = sub_name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	

}
