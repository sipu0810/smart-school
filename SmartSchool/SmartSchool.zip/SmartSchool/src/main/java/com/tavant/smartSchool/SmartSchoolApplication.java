package com.tavant.smartSchool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartSchoolApplication.class, args);
	}

}

