package com.tavant.smartSchool.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Homework {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int h_id;
	private String subject;
	private Date date;
	private String homework;
	//private String remark;
//	
//	@ManyToOne
//	@JoinColumn(name="s_id")
//	private Student student;
	
	public int getH_id() {
		return h_id;
	}
	public void setH_id(int h_id) {
		this.h_id = h_id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="DD-MM-YYYY")
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getHomework() {
		return homework;
	}
	public void setHomework(String homework) {
		this.homework = homework;
	}
	

}
