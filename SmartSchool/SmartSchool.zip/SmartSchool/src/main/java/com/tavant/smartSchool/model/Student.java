package com.tavant.smartSchool.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.xml.crypto.Data;

import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Student {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String sname;
	private String Parentname;
	private String parentmob;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy", timezone =" UTC")
	private Date dob;	
	private String gender;
	private int className;
	private String address;
//	
//	@OneToMany(cascade = CascadeType.ALL,
//            fetch = FetchType.LAZY)
//	private List<Homework> homework;
	
//	public List<Homework> getHomework() {
//		return homework;
//	}
//	public void setHomework(List<Homework> homework) {
//		this.homework = homework;
//	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getParentname() {
		return Parentname;
	}
	public void setParentname(String parentname) {
		Parentname = parentname;
	}
	public String getParentmob() {
		return parentmob;
	}
	public void setParentmob(String parentmob) {
		this.parentmob = parentmob;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getClassName() {
		return className;
	}
	public void setClassName(int className) {
		this.className = className;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
	
	

}
