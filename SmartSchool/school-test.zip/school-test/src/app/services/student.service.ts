import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
//import { Observable } from 'rxjs/Observable';

const httpOptions={
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
@Injectable()
export class StudentService {

  constructor(private http:HttpClient) { }

  getStudents(){
    return this.http.get('/server/api/v1/students');
  }

  getStudent(id : number){
    return this.http.get('/server/api/v1/students/'+id);
  }
  createStudentRegistration(student){
    let body= JSON.stringify(student);
    return this.http.post('/server/api/v1/students',body,httpOptions); 
  }
}
