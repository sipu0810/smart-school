import { Component, OnInit } from '@angular/core';
import {StudentService} from '../../services/student.service';
import {ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-view-registration',
  templateUrl: './view-registration.component.html',
  styleUrls: ['./view-registration.component.css']
})
export class ViewRegistrationComponent implements OnInit {
  public studentReg;
 // route: any;
  constructor(private studentService: StudentService,private route: ActivatedRoute) { }

  
  ngOnInit() {
    this.getStudentReg(this.route.snapshot.params.id);
  }

  getStudentReg(id: number){
    this.studentService.getStudent(id).subscribe(
      data=>{
        this.studentReg=data;
      },
      err=>console.error(err),
      ()=>console.log('student loaded')
    );
  }
}
