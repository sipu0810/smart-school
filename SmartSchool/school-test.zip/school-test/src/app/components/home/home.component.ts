import { Component, OnInit } from '@angular/core';
import { StudentService } from '../../services/student.service'
import{FormGroup,FormControl,Validators} from '@angular/forms';
import { Observable } from 'rxjs';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  models: string[]=[
    '1 ',
    '2 ',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',

  ];
  studentform: FormGroup;
  validmsg: string="";

  constructor(private studentService: StudentService) { }

  ngOnInit() {
    this.studentform= new FormGroup({
      sname: new FormControl('',Validators.required),
      parentname: new FormControl('',Validators.required),
      parentmob: new FormControl('',Validators.required),
      dob: new FormControl('',Validators.required),
      className: new FormControl('', Validators.required),
      gender: new FormControl('',Validators.required),
      address: new FormControl('',Validators.required)
    });
  }

  submitRegistration(){
   // console.log("hello");
    if(this.studentform.valid){
      this.validmsg="Registered Successfully. Thank You!";
      this.studentService.createStudentRegistration(this.studentform.value).subscribe(
        data=>{
          this.studentform.reset();
          return true;
        },
        error=>{
          return Observable.throw(error);
        }
      )
    }
    else{
      this.validmsg="please fill the form.";
    }
  }

}
