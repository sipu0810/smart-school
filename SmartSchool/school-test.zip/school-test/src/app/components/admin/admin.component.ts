import { Component, OnInit } from '@angular/core';
import { StudentService } from '../../services/student.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  public students;

  constructor(private studentService: StudentService) { }

  ngOnInit() {
    this.getStudents();
  }
  getStudents(){
    this.studentService.getStudents().subscribe(
      data=>{this.students=data},
      err=> console.error(err),
      () => console.log('Students loaded')
    );
  }

}
